/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Jonathan
 */
public class AvaliacaoFisica {
    private Pessoa aluno;
    private LocalDate data;
    private double peso;
    private double altura;
    private int idade;
    private double imc;
    
    AvaliacaoFisica(Pessoa aluno) {
        this.aluno = aluno;
        data = LocalDate.now();
    }
    
    public void setPeso(double peso) {
        this.peso = peso;
    }
    public double getPeso() {
        return peso;
    }
    public void setAltura(double altura) {
        this.altura = altura;
    }
    public double getAltura() {
        return altura;
    }
    
    public double calcularIMC() {
        imc = peso / (altura * altura);
        return imc;
    }
    public void calcularIdade() {
        idade = Period.between(aluno.getDataNascimento(), data).getYears();
    }
    public String exibirDados() {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        
        String retorno = "";
        retorno += "Nome: " + aluno.getNome() + "\n";
        retorno += "Idade: " + idade + "\n";
        retorno += "Data da avaliacao: " + data.format(formato) + "\n";
        retorno += "IMC: " + imc;
        return retorno;
    }
}
