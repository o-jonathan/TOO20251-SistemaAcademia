/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.time.LocalDate;

/**
 *
 * @author Jonathan
 */
public class AvaliacaoFisicaTeste {
    public static void main(String[] args) {
        Pessoa aluno = new Pessoa("Jonathan");
        AvaliacaoFisica af = new AvaliacaoFisica(aluno);
        
        aluno.setDataNascimento(LocalDate.of(2006, 03, 27));
        af.setPeso(60);
        af.setAltura(1.73);
        
        af.calcularIdade();
        af.calcularIMC();
        
        System.out.println(af.exibirDados());
        System.out.println("");
        aluno.adicionarAvaliacao(af);
        System.out.println(aluno.exibirDados());
    }
}
