/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 20241PF.CC0020
 */
public class Pessoa {
        //Atributos
    private LocalDate dataNascimento;
    private String nome;
    private String cpf;
    private List<AvaliacaoFisica> avaliacoes;
    
        //Construtores
    Pessoa() {
        this.avaliacoes = new ArrayList<>();
    }
    Pessoa(String n) {
        nome = n;
        this.avaliacoes = new ArrayList<>();
    }
    Pessoa(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
        this.avaliacoes = new ArrayList<>();
    }
    
        //Métodos
    public String exibirDados() {
        String aux = "Dados da Pessoa cadastrada: \n";
        aux += "Nome: " + nome + "\n";
        if (cpf != null)
            aux += "CPF: " + cpf + "\n";
        aux += "Quantidade de avaliacoes: " + getAvaliacoes().size() + "\n";
        
        return aux;
    }
    public void adicionarAvaliacao(AvaliacaoFisica avaliacao) {
        avaliacoes.add(avaliacao);
    }
    
        //Getters
    public String getNome() {
        return nome;
    }
    public String getCpf() {
        return cpf;
    }
    public LocalDate getDataNascimento() {
        return dataNascimento;
    }
    public List<AvaliacaoFisica> getAvaliacoes() {
        return avaliacoes;
    }
    
        //Setters
    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public void setDataNascimento(LocalDate dtN) {
        this.dataNascimento = dtN;
    }
}
